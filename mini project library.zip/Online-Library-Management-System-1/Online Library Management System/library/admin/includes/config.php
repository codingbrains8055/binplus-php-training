<?php
$server = "localhost";
$username = "root";
$pass = "Ani@8127";
$DBname = "library";
$con = mysqli_connect($server, $username, $pass, $DBname) or die(mysqli_error($con));
?>